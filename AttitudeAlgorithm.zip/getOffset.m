function gyroOffset = getOffset(Gyro)
    gyroOffset = mean(Gyro)';
end