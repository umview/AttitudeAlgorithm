# AttitudeAlgorithm
AttitudeAlgorithm
四元数姿态解算算法matlab实现（未完）
